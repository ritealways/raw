import os
from dotenv import load_dotenv

load_dotenv()

HF_TOKEN = os.getenv("HF_TOKEN")
LLM_MODEL = os.getenv("LLM_MODEL", "meta-llama/Llama-3.1-8B-Instruct")

if not HF_TOKEN:
    raise RuntimeError(
        "HF_TOKEN is missing. Copy .env.example to .env and add your Hugging Face token."
    )
