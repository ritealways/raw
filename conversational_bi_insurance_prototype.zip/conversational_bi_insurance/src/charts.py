import plotly.express as px


def make_chart(result, plan):
    if result["type"] == "table":
        data = result["data"]
        x = plan["group_by"]
        y = plan["metric"]
        return px.bar(data, x=x, y=y, title=f"{y} by {x}")

    if result["type"] == "trend":
        data = result["data"]
        return px.line(data, x="month", y=plan["metric"], markers=True,
                       title=f"Monthly {plan['metric']} trend")

    return None
