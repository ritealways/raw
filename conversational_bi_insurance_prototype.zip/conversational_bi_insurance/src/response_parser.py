import json
import re


def parse_json(text):
    text = text.strip()

    # Remove markdown fences if the model returns them.
    text = re.sub(r"^```json\s*", "", text, flags=re.I)
    text = re.sub(r"^```\s*", "", text)
    text = re.sub(r"\s*```$", "", text)

    start = text.find("{")
    end = text.rfind("}")

    if start == -1 or end == -1:
        raise ValueError("No JSON object found in LLM response.")

    return json.loads(text[start:end + 1])
