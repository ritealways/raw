import pandas as pd

ALLOWED_COLUMNS = {
    "member_id", "age", "gender", "region", "diagnosis",
    "provider_type", "claim_date", "premium", "claim_amount"
}

ALLOWED_OPERATIONS = {
    "count", "sum", "mean", "groupby", "trend", "filter_groupby"
}


def validate_plan(plan):
    if not isinstance(plan, dict):
        raise ValueError("LLM did not return a JSON object.")

    operation = plan.get("operation")
    if operation not in ALLOWED_OPERATIONS:
        raise ValueError(f"Unsupported operation: {operation}")

    for key in ["column", "group_by", "metric", "date_column"]:
        value = plan.get(key)
        if value and value not in ALLOWED_COLUMNS:
            raise ValueError(f"Column not allowed: {value}")

    for f in plan.get("filters", []):
        if f.get("column") not in ALLOWED_COLUMNS:
            raise ValueError("Filter column is not allowed.")
        if f.get("operator") != "equals":
            raise ValueError("Only equals filters are supported in this prototype.")

    return True


def apply_filters(df, filters):
    result = df.copy()

    for f in filters or []:
        result = result[
            result[f["column"]].astype(str).str.lower()
            == str(f["value"]).lower()
        ]

    return result


def execute_query(df, plan):
    validate_plan(plan)

    filtered = apply_filters(df, plan.get("filters", []))
    operation = plan["operation"]

    if operation == "count":
        return {"type": "metric", "value": int(filtered[plan["column"]].nunique())}

    if operation == "sum":
        return {"type": "metric", "value": float(filtered[plan["column"]].sum())}

    if operation == "mean":
        return {"type": "metric", "value": float(filtered[plan["column"]].mean())}

    if operation in {"groupby", "filter_groupby"}:
        result = (
            filtered.groupby(plan["group_by"], dropna=False)[plan["metric"]]
            .agg(plan.get("aggregation", "sum"))
            .reset_index()
        )
        return {"type": "table", "data": result}

    if operation == "trend":
        temp = filtered.copy()
        temp[plan["date_column"]] = pd.to_datetime(temp[plan["date_column"]])
        temp["month"] = temp[plan["date_column"]].dt.to_period("M").astype(str)
        result = (
            temp.groupby("month")[plan["metric"]]
            .agg(plan.get("aggregation", "sum"))
            .reset_index()
        )
        return {"type": "trend", "data": result}

    raise ValueError("Operation not implemented.")
