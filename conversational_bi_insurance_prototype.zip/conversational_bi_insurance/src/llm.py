from huggingface_hub import InferenceClient
from .config import HF_TOKEN, LLM_MODEL


class LLMClient:
    def __init__(self):
        self.client = InferenceClient(token=HF_TOKEN)

    def chat(self, messages, temperature=0.0, max_tokens=700):
        response = self.client.chat.completions.create(
            model=LLM_MODEL,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content
