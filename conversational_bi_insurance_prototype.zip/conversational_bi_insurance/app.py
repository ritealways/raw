import json
import pandas as pd
import streamlit as st

from src.llm import LLMClient
from src.prompts import SYSTEM_PROMPT
from src.response_parser import parse_json
from src.query_engine import execute_query
from src.charts import make_chart


st.set_page_config(
    page_title="Insurance Conversational BI",
    page_icon="📊",
    layout="wide",
)

st.title("📊 Insurance Conversational BI")
st.caption("Few-shot Llama + Pandas + Streamlit prototype")

@st.cache_data
def load_data():
    return pd.read_csv("data/insurance_data.csv")

df = load_data()

with st.sidebar:
    st.header("Dataset")
    st.metric("Rows", f"{len(df):,}")
    st.metric("Members", f"{df['member_id'].nunique():,}")
    st.write("Columns")
    st.code(", ".join(df.columns))

st.subheader("1. Quick EDA")

c1, c2, c3, c4 = st.columns(4)
c1.metric("Members", f"{df['member_id'].nunique():,}")
c2.metric("Total Claims", f"${df['claim_amount'].sum():,.0f}")
c3.metric("Avg Claim", f"${df['claim_amount'].mean():,.0f}")
c4.metric("Avg Premium", f"${df['premium'].mean():,.0f}")

with st.expander("Preview data"):
    st.dataframe(df.head(20), use_container_width=True)

st.divider()
st.subheader("2. Ask your insurance data")

st.info(
    "Try: 'Show claims by region', "
    "'How many members do we have?', "
    "'Show claims by region for diabetes members', "
    "or 'Show monthly claim trend'."
)

if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.write(message["content"])

question = st.chat_input("Ask a business question...")

if question:
    st.session_state.messages.append(
        {"role": "user", "content": question}
    )

    with st.chat_message("user"):
        st.write(question)

    with st.chat_message("assistant"):
        with st.spinner("Llama is understanding your question..."):
            try:
                client = LLMClient()

                # For the first prototype, use the fixed few-shot system prompt.
                messages = [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": question},
                ]

                raw = client.chat(messages)
                plan = parse_json(raw)

                st.caption("LLM query plan")
                st.json(plan)

                result = execute_query(df, plan)

                if result["type"] == "metric":
                    value = result["value"]
                    if plan["operation"] == "count":
                        st.metric("Answer", f"{value:,}")
                    else:
                        st.metric("Answer", f"${value:,.2f}")

                else:
                    st.dataframe(
                        result["data"],
                        use_container_width=True
                    )

                    fig = make_chart(result, plan)
                    if fig:
                        st.plotly_chart(
                            fig,
                            use_container_width=True
                        )

                explanation = (
                    "I converted your question into a structured query plan, "
                    "executed that plan against the insurance dataset, and "
                    "displayed the result."
                )
                st.write(explanation)

                st.session_state.messages.append(
                    {"role": "assistant", "content": explanation}
                )

            except Exception as exc:
                st.error(
                    "The request could not be completed. "
                    "Check your HF token/model and the question."
                )
                st.exception(exc)
