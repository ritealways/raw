"""
app.py

Conversational BI prototype -- entry point.

Run with:  streamlit run app.py

This file is intentionally thin: it wires together the modules in src/
and renders the UI. All the "real" logic lives in src/.
"""

from __future__ import annotations
import os
import pandas as pd
import streamlit as st
from dotenv import load_dotenv

from src.profiling.eda import full_eda_report, eda_summary_text
from src.visualization.charts import auto_eda_charts, correlation_heatmap
from src.llm.model import get_backend
from src.query.planner import plan_question
from src.execution.safe_exec import execute_plan, ExecutionError
from src.query.responder import summarize_result

load_dotenv()

st.set_page_config(page_title="Conversational BI", layout="wide")
st.title("💬 Conversational BI Prototype")
st.caption("Upload any CSV, get automatic EDA, then chat with your data in plain English.")

# ---------------------------------------------------------------------
# Session state
# ---------------------------------------------------------------------
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []  # list of {question, answer_summary, plan}
if "last_plan" not in st.session_state:
    st.session_state.last_plan = None
if "backend" not in st.session_state:
    with st.spinner("Loading LLM backend..."):
        st.session_state.backend = get_backend()

backend_name = os.getenv("LLM_BACKEND", "rule_based")
st.sidebar.header("⚙️ Settings")
st.sidebar.write(f"**LLM backend:** `{backend_name}`")
if backend_name == "rule_based":
    st.sidebar.info(
        "Running in rule-based fallback mode (no GPU/model download needed). "
        "Set LLM_BACKEND=hf_local in .env to use a real Hugging Face Llama model."
    )

uploaded = st.file_uploader("Upload a CSV file", type=["csv"])
use_sample = st.checkbox("Use bundled sample healthcare dataset instead", value=uploaded is None)

df = None
if uploaded is not None:
    try:
        df = pd.read_csv(uploaded)
    except Exception as e:
        st.error(f"Could not read that CSV file: {e}")
elif use_sample:
    sample_path = os.path.join(os.path.dirname(__file__), "data", "sample.csv")
    df = pd.read_csv(sample_path)

if df is None:
    st.info("Upload a CSV (or check the sample-data box) to get started.")
    st.stop()

if df.empty:
    st.error("The uploaded CSV has no rows.")
    st.stop()

# ---------------------------------------------------------------------
# Automated EDA
# ---------------------------------------------------------------------
report = full_eda_report(df)
schema = report["schema"]

tab_eda, tab_chat = st.tabs(["📊 Automatic EDA", "💬 Chat with your data"])

with tab_eda:
    ov = report["overview"]
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Rows", ov["n_rows"])
    c2.metric("Columns", ov["n_columns"])
    c3.metric("Duplicate rows", ov["duplicate_rows"])
    c4.metric("Memory (MB)", ov["memory_usage_mb"])

    st.subheader("Column overview")
    st.dataframe(pd.DataFrame([c.__dict__ for c in schema]), use_container_width=True)

    st.subheader("Missing values")
    st.dataframe(report["missing"], use_container_width=True)

    if not report["numeric_summary"].empty:
        st.subheader("Numeric summary (incl. outlier counts, IQR method)")
        st.dataframe(report["numeric_summary"], use_container_width=True)

    if report["categorical_summary"]:
        st.subheader("Categorical summary (top values)")
        for col, info in report["categorical_summary"].items():
            st.write(f"**{col}** ({info['n_unique']} unique values)")
            st.bar_chart(pd.Series(info["top_values"]))

    st.subheader("Auto-generated charts")
    for title, fig in auto_eda_charts(df, schema):
        st.plotly_chart(fig, use_container_width=True, key=f"eda_{title}")

with tab_chat:
    st.write("Ask a question about the uploaded dataset in plain English.")
    for turn in st.session_state.chat_history:
        with st.chat_message("user"):
            st.write(turn["question"])
        with st.chat_message("assistant"):
            st.write(turn["answer_summary"])

    question = st.chat_input("e.g. What is the average claim amount for Diabetes patients?")
    if question:
        with st.chat_message("user"):
            st.write(question)

        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                summary_text = eda_summary_text(report)
                result = plan_question(
                    backend=st.session_state.backend,
                    question=question,
                    schema=schema,
                    eda_summary_text=summary_text,
                    history=st.session_state.chat_history,
                    previous_plan=st.session_state.last_plan,
                )

            if not result["ok"]:
                st.warning(result["error"])
                answer_text = result["error"]
            else:
                plan = result["plan"]
                with st.expander("Show analytical plan (debug)"):
                    st.json(plan)
                try:
                    exec_result = execute_plan(df, plan)
                    answer_text = summarize_result(plan, exec_result)
                    st.write(answer_text)
                    if exec_result.get("table") is not None:
                        st.dataframe(exec_result["table"], use_container_width=True)
                    if exec_result.get("figure") is not None:
                        st.plotly_chart(exec_result["figure"], use_container_width=True)
                    st.session_state.last_plan = plan
                except ExecutionError as e:
                    answer_text = f"I built a plan for that question but couldn't safely execute it: {e}"
                    st.error(answer_text)

            st.session_state.chat_history.append(
                {"question": question, "answer_summary": answer_text}
            )
