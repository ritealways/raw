"""
tests/test_basic.py

Run with: pytest tests/

These tests deliberately avoid loading any Hugging Face model - they use
the rule_based backend and pure-pandas modules, so they run fast and
offline. This covers PART 16's requirements: CSV loading, schema
detection, EDA, question understanding, plan validation, invalid
columns, code safety, aggregation, filtering, and follow-up questions.
"""

import os
import sys
import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.utils.schema import build_schema, schema_to_prompt_text
from src.profiling.eda import full_eda_report, eda_summary_text
from src.llm.model import RuleBasedBackend
from src.query.planner import plan_question, validate_plan, merge_follow_up
from src.execution.safe_exec import execute_plan, safe_eval_expression, ExecutionError


@pytest.fixture
def df():
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "sample.csv")
    return pd.read_csv(path)


@pytest.fixture
def backend():
    return RuleBasedBackend()


def test_csv_loading(df):
    assert len(df) > 0
    assert "claim_amount" in df.columns


def test_schema_detection(df):
    schema = build_schema(df)
    roles = {c.name: c.role for c in schema}
    assert roles["age"] == "numeric"
    assert roles["disease"] == "categorical"
    assert roles["claim_date"] == "date"
    assert schema_to_prompt_text(schema)  # non-empty text


def test_eda_report_runs(df):
    report = full_eda_report(df)
    assert report["overview"]["n_rows"] == len(df)
    assert eda_summary_text(report)


def test_aggregation_question(df, backend):
    schema = build_schema(df)
    summary = eda_summary_text(full_eda_report(df))
    result = plan_question(backend, "What is the average claim amount for diabetes patients?",
                            schema, summary, history=[])
    assert result["ok"], result["error"]
    exec_result = execute_plan(df, result["plan"])
    assert exec_result["result_type"] == "scalar"
    assert exec_result["value"] > 0


def test_groupby_question(df, backend):
    schema = build_schema(df)
    summary = eda_summary_text(full_eda_report(df))
    result = plan_question(backend, "What is the total claim amount by state?", schema, summary, history=[])
    assert result["ok"], result["error"]
    exec_result = execute_plan(df, result["plan"])
    assert exec_result["result_type"] == "table"
    assert len(exec_result["table"]) > 0


def test_hallucinated_column_is_rejected(df):
    schema = build_schema(df)
    fake_plan = {
        "intent": "aggregation", "columns": ["premium_amount"], "operation": "mean",
        "group_by": [], "filters": [], "visualization": "none", "explanation": "test",
    }
    valid_columns = [c.name for c in schema]
    is_valid, problems = validate_plan(fake_plan, valid_columns)
    assert not is_valid
    assert "premium_amount" in problems[0]


def test_follow_up_merging():
    previous = {"intent": "aggregation", "columns": ["claim_amount"], "operation": "mean",
                "group_by": [], "filters": [{"column": "disease", "operator": "equals", "value": "Diabetes"}],
                "visualization": "none", "explanation": "prev"}
    follow_up = {"intent": "follow_up_filter", "columns": ["state"], "operation": "reuse_previous_plan",
                 "group_by": [], "filters": [{"column": "state", "operator": "equals", "value": "California"}],
                 "visualization": "same_as_previous", "explanation": "only California"}
    merged = merge_follow_up(follow_up, previous)
    assert len(merged["filters"]) == 2


def test_safe_exec_blocks_dangerous_code(df):
    with pytest.raises(ExecutionError):
        safe_eval_expression("__import__('os').system('rm -rf /')", df)
    with pytest.raises(ExecutionError):
        safe_eval_expression("open('/etc/passwd').read()", df)


def test_safe_exec_allows_pandas_expression(df):
    result = safe_eval_expression('df[df["disease"] == "Diabetes"]["claim_amount"].mean()', df)
    assert result > 0


def test_unknown_question_does_not_hallucinate(df, backend):
    schema = build_schema(df)
    summary = eda_summary_text(full_eda_report(df))
    result = plan_question(backend, "What is the average premium amount?", schema, summary, history=[])
    assert not result["ok"]
    assert "couldn't find" in result["error"].lower() or "confident" in result["error"].lower()
