# Conversational BI Prototype

Chat with any CSV file in plain English. Upload a dataset, get automatic EDA,
then ask questions like *"What is the average claim amount for diabetes
patients?"* or *"Show monthly revenue trends."* — no domain-specific code.

---

## 1. What is Conversational BI, in plain language?

Normal BI tools (Excel, Power BI, Tableau) make YOU build charts and filters.
Conversational BI flips that: you type a question in English, and the app
figures out which numbers to compute and which chart to draw. "Conversational"
means it also remembers earlier questions, so "what about only California?"
makes sense as a follow-up.

## 2. Why do we need an LLM at all?

Because the question is written in free-form English and the dataset can be
**anything** — insurance, sales, HR, e-commerce. A traditional program would
need a hand-written `if "claim" in question` rule for every possible phrasing
and every possible dataset. An LLM can read the column names + a description
of the question and produce a structured plan ("average `claim_amount` where
`disease` = Diabetes") without us writing that rule ourselves.

## 3. What does the LLM actually do here?

It does **not** touch your data directly. It only sees:
- the column names, types, and a few sample values (the "schema")
- a short statistics summary (missing values, row count, etc.)
- your question and recent chat history
- a handful of worked examples ("few-shot examples")

From that, it outputs a small JSON object describing *what to compute* — not
prose, not raw Python. See `src/prompts/few_shot.py`.

## 4–8. What do the other pieces do?

| Tool | Role in this app |
|---|---|
| **Python** | Glue language for everything below |
| **Pandas** | Does the actual filtering/grouping/math on your CSV |
| **Streamlit** | The web UI you interact with (upload box, chat box, charts) |
| **Hugging Face** | Where the LLM (Llama or similar) comes from, and the `transformers` library used to run it |
| **Llama** | The open-weights model family this project is designed around |

## 9. What is few-shot prompting?

**Zero-shot** = just ask the model to answer, no examples. It invents its own
output format every time — unreliable to parse and prone to hallucinating
column names.

**One-shot** = one example. Teaches the *format* but not the *variety* of
question types (aggregation vs ranking vs time-series vs follow-up).

**Few-shot** = 5–8 diverse examples, deliberately drawn from *different
business domains* (insurance, sales, HR, e-commerce, banking) so the model
learns the pattern "question → structured plan", not domain-specific wording.
This is why the same prompt template works on a sales CSV or an HR CSV
without any code changes. See `FEW_SHOT_EXAMPLES` in
`src/prompts/few_shot.py`.

## 10–17. What happens step by step

1. **Upload CSV** → `app.py` reads it with `pandas.read_csv`.
2. **Automatic EDA** → `src/profiling/eda.py` computes row/column counts,
   missing values, outliers, correlations, etc., with no dataset-specific
   code — it works purely from column *types*, not names.
3. **You ask a question** → `src/utils/schema.py` builds a compact text
   description of the columns (never the raw rows).
4. **Prompt built** → `src/prompts/few_shot.py` combines schema + EDA
   summary + chat history + few-shot examples + your question into one
   prompt.
5. **LLM call** → `src/llm/model.py` sends that prompt to a Hugging Face
   model (or the offline rule-based fallback) and gets back JSON.
6. **Validation** → `src/query/planner.py` checks every column name in the
   JSON plan against the real schema. Unknown column → refuse, don't guess.
   *This is how hallucinated columns are prevented (see #18 below).*
7. **Safe execution** → `src/execution/safe_exec.py` interprets the JSON
   plan directly with real pandas calls — there is no `eval()`/`exec()` of
   LLM-written code in this primary path.
8. **Answer + chart** → `src/query/responder.py` turns the result into one
   plain-language sentence; `src/visualization/charts.py` builds the chart.

## 18. How does it avoid hallucinating columns?

Two layers: (a) the few-shot examples explicitly instruct the model "only
use columns listed in SCHEMA, otherwise say intent=unknown", and (b) even if
the model ignores that, `validate_plan()` in `planner.py` cross-checks every
column name in the returned JSON against the real dataframe columns and
rejects the plan if anything doesn't match.

## 19. Why not send the whole dataset to the LLM?

Three reasons: (1) cost/latency — a 100k-row CSV is far more tokens than any
model's context window; (2) the LLM doesn't need raw rows to write an
aggregation plan, only the schema and stats; (3) sending raw data to an LLM
API (if you ever switch to a hosted one) is also a privacy consideration.

## 20. Why not blindly execute generated Python?

Because **LLM output is untrusted input** — it could contain a mistake or
(if the prompt is ever manipulated) something malicious. Executing arbitrary
`eval()`/`exec()` code from a language model is a classic injection
vulnerability. This project's primary execution path avoids `eval`/`exec`
entirely by interpreting a constrained JSON plan instead. See the module
docstring in `src/execution/safe_exec.py` for the optional AST-whitelisted
fallback and its explicit limitations.

## 21. What about large datasets?

This prototype loads the whole CSV into memory with pandas, fine up to
roughly tens of MB. Beyond that:
- **10–100MB**: still fine in pandas on most laptops; consider
  `usecols`/`dtype` hints to cut memory.
- **~1GB**: switch the storage/query layer to **DuckDB** (`duckdb.sql(...)`)
  or **Parquet** files — both let you query without loading everything into
  RAM, and DuckDB accepts near-SQL you can generate the same way this
  project generates JSON plans.
- **10GB+**: you need a real analytical engine (DuckDB, Polars in
  streaming mode, or a warehouse like BigQuery/Snowflake) and the LLM
  should generate SQL against that engine, not pandas code.
In all cases, the LLM only ever sees the schema/profile/sample rows — never
the full data — so this scaling change doesn't touch the prompt design.

## 22. How does this become production-ready?

- Swap the rule-based fallback for a real Llama model (see Setup below) or
  a hosted inference endpoint for reliability.
- Move execution into an isolated subprocess/container with a hard timeout,
  no network, and a memory limit (the current sandbox is prototype-grade,
  not production-grade — see the caveat in `safe_exec.py`).
- Add logging/observability (prompts, generated plans, execution time,
  errors) — see the Observability section below.
- Add authentication and per-user rate limiting if this is exposed publicly.
- Move from CSV upload to a real data warehouse connection.

---

## Is RAG needed for this project?

**Not for V1.** RAG (retrieval-augmented generation) is for retrieving
relevant *unstructured text* chunks from a large document store. This app's
"knowledge" is a CSV's schema and statistics, which comfortably fit in a
single prompt — there's nothing to retrieve. RAG would become relevant in a
V2 if you wanted to, say, let users ask about a data dictionary/glossary
spread across many PDFs, or search past conversations at scale — then you'd
embed those documents and retrieve relevant chunks before prompting.

## Is an agent architecture needed?

**Not for V1.** Compare:
- **Simple pipeline (used here):** question → one structured plan → execute
  → answer. Fast, predictable, easy to test and debug.
- **Agent with tools:** the LLM decides, step by step, which tool to call
  next (profile the data, then filter, then aggregate, then chart), looping
  until it thinks it's done. More flexible for open-ended multi-step
  analysis, but slower, harder to test, and more places for it to go wrong.

Start with the simple pipeline (this prototype). Move to an agent+tools
design in V2 once you have specific multi-step questions the single-plan
approach can't handle (e.g. "find the columns most correlated with churn,
then break that down by region").

---

## Architecture

```
                USER
                 |
                 v
          Streamlit UI (app.py)
                 |
                 v
       Automated EDA Engine  <----------------+
      (src/profiling/eda.py)                  |
                 |                             |
                 v                             |
        Schema / Metadata Builder              |
       (src/utils/schema.py)                   |
                 |                             |
                 v                             |
   Conversation Manager (chat_history in       |
        Streamlit session_state)               |
                 |                             |
                 v                             |
       Few-Shot Prompt Builder  ---------------+
      (src/prompts/few_shot.py)
                 |
                 v
         LLM Backend (Llama via HF,
         or rule_based fallback)
        (src/llm/model.py)
                 |
                 v
         Raw JSON text response
                 |
                 v
     Plan Parser + Validator
     (src/query/planner.py)  -- rejects unknown columns
                 |
                 v
        Safe Plan Executor
    (src/execution/safe_exec.py) -- no eval/exec of LLM text
                 |
        +--------+--------+
        |                 |
        v                 v
     Result Table      Chart (plotly)
     / Scalar        (src/visualization/charts.py)
        |                 |
        +--------+--------+
                 |
                 v
      Natural Language Summary
      (src/query/responder.py)
                 |
                 v
              USER
```

---

## Project Structure

```
conversational-bi/
├── app.py                     # Streamlit entry point
├── requirements.txt
├── .env.example
├── README.md
├── data/
│   └── sample.csv             # Bundled healthcare/insurance sample dataset
├── src/
│   ├── llm/model.py           # HF Llama loader + rule-based offline fallback
│   ├── profiling/eda.py       # Automated, domain-independent EDA engine
│   ├── query/planner.py       # Prompt building + JSON plan parsing/validation
│   ├── query/responder.py     # Plan/result -> plain-language sentence
│   ├── execution/safe_exec.py # Safe plan interpreter + AST-guarded fallback
│   ├── visualization/charts.py# Plotly chart builders
│   ├── prompts/few_shot.py    # Few-shot example library + prompt template
│   └── utils/schema.py        # Column type/role inference, schema text
└── tests/
    └── test_basic.py          # Offline tests (no model download needed)
```

---

## Setup in VS Code (from an empty folder)

```bash
# 1. Unzip this project, then open the folder in VS Code
cd conversational-bi

# 2. Create and activate a virtual environment
python -m venv venv
venv\Scripts\activate        # Windows
source venv/bin/activate     # macOS/Linux

# 3. Install dependencies
pip install -r requirements.txt

# 4. Copy the env file and edit if needed (optional for V1 — default works offline)
cp .env.example .env
```

## How to Run

```bash
streamlit run app.py
```

Open the URL Streamlit prints (usually http://localhost:8501). Check the
"Use bundled sample healthcare dataset" box, or upload your own CSV.

By default `LLM_BACKEND=rule_based` in `.env.example`, so the app works
immediately with **no model download and no GPU** — it uses a small
keyword+schema matcher that mimics what a well-prompted LLM would output,
so you can see the whole pipeline working end to end on day one.

### Switching to a real Hugging Face Llama model

Edit `.env`:
```
LLM_BACKEND=hf_local
HF_MODEL_NAME=meta-llama/Llama-3.2-1B-Instruct
LOAD_IN_4BIT=false
HUGGINGFACE_TOKEN=<your token, needed because Llama models are gated>
```
Then `huggingface-cli login` once, and re-run `streamlit run app.py`. First
run will download the model (a few GB) and load it into RAM/VRAM.

**Sizing guide:**
| Hardware | Recommended model | Notes |
|---|---|---|
| CPU only, 8–16GB RAM | 1B–3B instruct model (Llama-3.2-1B/3B, Qwen2.5-1.5B) | Expect several seconds per answer |
| GPU, 6–8GB VRAM | 7–8B model, 4-bit quantized (`LOAD_IN_4BIT=true`, needs `bitsandbytes`) | Good balance |
| GPU, 16GB+ VRAM | 7–8B model, 8-bit or fp16 | Fastest |
| No local hardware | Hugging Face Inference Endpoint, or a local server like Ollama/vLLM | Swap `generate()` in `src/llm/model.py` |

Quantization (4-bit/8-bit) trades a little accuracy for a big drop in
memory use — usually worth it for a prototype.

---

## How to Test

```bash
pytest tests/ -v
```

These run entirely offline (no model download). Manual test example with
the bundled sample dataset:

| Question | Expected behavior |
|---|---|
| "What is the average claim amount for diabetes patients?" | Filters `disease == Diabetes`, returns mean of `claim_amount` |
| "What is the total claim amount by state?" | Groups by `state`, sums `claim_amount`, shows bar chart |
| "What are the top 5 hospitals by claim amount?" | Groups by `hospital`, sums, sorts descending, keeps 5 |
| "What about only California?" (as a follow-up) | Re-uses the previous plan + adds a `state == California` filter |
| "What is the average premium amount?" | No `premium` column exists → app says so instead of guessing |

To try a different domain, just upload a sales/HR/e-commerce CSV — no code
changes needed.

---

## Troubleshooting

- **`ModuleNotFoundError: No module named 'src'`** — run `streamlit run
  app.py` from the project root, not from inside `src/`.
- **App works but every answer says "couldn't find that column"** — the
  rule-based fallback only matches column names/synonyms it can see in your
  question; try naming the column more literally, or switch to a real LLM
  backend for more flexible language understanding.
- **Llama model won't download** — gated models need `huggingface-cli
  login` with a token that has accepted the model's license on
  huggingface.co. Use `Qwen/Qwen2.5-1.5B-Instruct` instead if you don't
  want to wait for Llama access.
- **Out of memory loading the model** — use a smaller model, or set
  `LOAD_IN_4BIT=true` on a CUDA GPU, or fall back to `LLM_BACKEND=rule_based`.
- **Charts don't show** — make sure `plotly` installed correctly
  (`pip show plotly`); reinstall with `pip install -r requirements.txt`.

---

## Observability (future)

Not required for V1, but worth planning for: log each turn's question,
built prompt, raw LLM output, parsed plan, execution time, and any errors
(simple `logging` module is enough to start). Once you have real usage,
tools like **MLflow** (track prompts/plans as experiment runs) or
**LangSmith** (LLM-call tracing) help you see where answers go wrong and
build an evaluation dataset of (question, expected plan) pairs to catch
regressions as you improve prompts.

## V1 → V2 → Production roadmap

- **V1 (this prototype):** single-shot plan generation, pandas execution,
  Streamlit UI, offline rule-based fallback + optional local Llama.
- **V2:** real Llama backend by default, DuckDB for larger files, a second
  LLM call to narrate results more naturally, basic prompt/plan logging,
  a small evaluation set of (question → expected plan) pairs.
- **Production:** isolated sandboxed execution (subprocess/container, no
  network, hard timeouts), authentication, hosted inference endpoint for
  reliability/latency, observability (MLflow/LangSmith), support for
  SQL-backed warehouses instead of CSV upload.
