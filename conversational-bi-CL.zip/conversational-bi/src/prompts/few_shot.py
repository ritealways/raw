"""
src/prompts/few_shot.py

WHAT:
The few-shot example library + the system prompt template that turns a
user's natural-language question into a STRUCTURED JSON "analytical plan".

WHY (few-shot prompting):
- Zero-shot ("just answer the question") lets the model invent its own
  output format every time -> impossible to parse reliably, and it will
  happily invent column names that don't exist (hallucination).
- One-shot (a single example) teaches the format but not the range of
  operations (filter vs groupby vs rank vs time-series vs compare).
- Few-shot (5-8 diverse examples) teaches the model:
    1. the exact JSON schema to output
    2. how to map "average / mean" -> aggregation, "top N" -> ranking,
       "trend/over time" -> time-series, "compare" -> comparison, etc.
    3. that it must ONLY use column names that exist in the schema block
       given to it in the same prompt (this is what reduces hallucination)
- The examples below use DIFFERENT business domains (insurance, sales,
  HR, e-commerce, banking) on purpose, so the model learns the PATTERN
  ("question -> plan") rather than memorizing insurance-specific wording.

HOW:
`SYSTEM_PROMPT_TEMPLATE.format(schema=..., few_shot=..., history=...,
question=...)` builds the final prompt sent to the LLM. See
src/query/planner.py for how it's assembled and parsed.
"""

FEW_SHOT_EXAMPLES = [
    {
        "domain": "insurance",
        "question": "What is the average claim amount for diabetic patients?",
        "plan": {
            "intent": "aggregation",
            "columns": ["claim_amount", "disease"],
            "operation": "mean",
            "group_by": [],
            "filters": [{"column": "disease", "operator": "equals", "value": "Diabetes"}],
            "visualization": "none",
            "explanation": "Filter rows where disease is Diabetes, then average claim_amount."
        },
    },
    {
        "domain": "sales",
        "question": "What is the average revenue by product category?",
        "plan": {
            "intent": "aggregation",
            "columns": ["revenue", "category"],
            "operation": "mean",
            "group_by": ["category"],
            "filters": [],
            "visualization": "bar",
            "explanation": "Group rows by category and compute the mean of revenue for each group."
        },
    },
    {
        "domain": "healthcare",
        "question": "Show claims for patients older than 60.",
        "plan": {
            "intent": "filter",
            "columns": ["age", "claim_amount"],
            "operation": "list",
            "group_by": [],
            "filters": [{"column": "age", "operator": "greater_than", "value": 60}],
            "visualization": "table",
            "explanation": "Filter rows where age is greater than 60 and show them as a table."
        },
    },
    {
        "domain": "healthcare",
        "question": "What are the top 10 hospitals by claim amount?",
        "plan": {
            "intent": "ranking",
            "columns": ["hospital", "claim_amount"],
            "operation": "sum",
            "group_by": ["hospital"],
            "filters": [],
            "top_n": 10,
            "sort": "descending",
            "visualization": "bar",
            "explanation": "Group by hospital, sum claim_amount, sort descending, keep top 10."
        },
    },
    {
        "domain": "ecommerce",
        "question": "Show monthly sales for the last 12 months.",
        "plan": {
            "intent": "time_series",
            "columns": ["order_date", "sales"],
            "operation": "sum",
            "group_by": ["order_date:month"],
            "filters": [],
            "visualization": "line",
            "explanation": "Parse order_date, resample by month, sum sales for each month."
        },
    },
    {
        "domain": "sales",
        "question": "Compare revenue between 2024 and 2025.",
        "plan": {
            "intent": "comparison",
            "columns": ["order_date", "revenue"],
            "operation": "sum",
            "group_by": ["order_date:year"],
            "filters": [{"column": "order_date", "operator": "year_in", "value": [2024, 2025]}],
            "visualization": "bar",
            "explanation": "Group revenue by year for 2024 and 2025 and compare the totals."
        },
    },
    {
        "domain": "hr",
        "question": "What percentage of employees churned?",
        "plan": {
            "intent": "percentage",
            "columns": ["attrition"],
            "operation": "percentage_true",
            "group_by": [],
            "filters": [],
            "visualization": "none",
            "explanation": "Compute the share of rows where attrition equals Yes/True."
        },
    },
    {
        "domain": "banking",
        "question": "What about only California?",  # follow-up example
        "plan": {
            "intent": "follow_up_filter",
            "columns": ["state"],
            "operation": "reuse_previous_plan",
            "group_by": [],
            "filters": [{"column": "state", "operator": "equals", "value": "California"}],
            "visualization": "same_as_previous",
            "explanation": "Re-run the previous analytical plan but add a filter for state = California."
        },
    },
]


PLAN_JSON_SCHEMA_DESCRIPTION = """
Return ONLY a single JSON object (no prose, no markdown fences) with this schema:
{
  "intent": "aggregation | filter | ranking | time_series | comparison | percentage | follow_up_filter | unknown",
  "columns": [ "<column names used, must exist in the schema below>" ],
  "operation": "mean | sum | count | min | max | median | percentage_true | list | reuse_previous_plan",
  "group_by": [ "<column name>" or "<column name>:month" or "<column name>:year" ],
  "filters": [ {"column": "...", "operator": "equals|not_equals|greater_than|less_than|contains|year_in", "value": <value>} ],
  "top_n": <integer or null>,
  "sort": "ascending | descending | null",
  "visualization": "bar | line | hist | box | scatter | heatmap | table | none | same_as_previous",
  "explanation": "one sentence, plain language, describing what will be computed"
}
Rules:
- Only use column names that appear in the SCHEMA block. Never invent a column.
- If the question cannot be answered with the given columns, set "intent" to "unknown"
  and leave "columns" empty -- do NOT guess a similar-sounding column.
- If the question is a follow-up (e.g. "what about X", "only for Y", "now show top 5"),
  set intent to "follow_up_filter" and describe only the DELTA vs the previous question.
"""


def build_few_shot_block(examples=None) -> str:
    import json
    examples = examples or FEW_SHOT_EXAMPLES
    blocks = []
    for ex in examples:
        blocks.append(
            f'Question: "{ex["question"]}"\n'
            f"Plan: {json.dumps(ex['plan'])}"
        )
    return "\n\n".join(blocks)


SYSTEM_PROMPT_TEMPLATE = """You are a data analyst assistant. You convert a user's natural-language
question about a dataset into a structured JSON analytical plan. You never answer in free text.
You never invent column names that are not listed in the SCHEMA section.

SCHEMA (columns available in the current dataset):
{schema}

DATA QUALITY / STATISTICS SUMMARY:
{eda_summary}

{plan_schema}

EXAMPLES (different domains, showing question -> plan mapping):
{few_shot}

CONVERSATION HISTORY (most recent last, may be empty):
{history}

Now produce the JSON plan for this new question. Output JSON only.
Question: "{question}"
Plan:"""


def build_prompt(schema_text: str, eda_summary: str, history_text: str, question: str) -> str:
    return SYSTEM_PROMPT_TEMPLATE.format(
        schema=schema_text,
        eda_summary=eda_summary,
        plan_schema=PLAN_JSON_SCHEMA_DESCRIPTION,
        few_shot=build_few_shot_block(),
        history=history_text or "(none)",
        question=question,
    )
