"""
src/execution/safe_exec.py

WHAT:
Executes an analytical plan against a pandas DataFrame and returns a
result (a number, a table, and/or a chart).

WHY THIS DESIGN (PART 9 - safe execution):
LLM-generated Python code is UNTRUSTED INPUT. The safest thing an app can
do is to never eval/exec free-form LLM text at all. So the PRIMARY path
here is a small, hand-written interpreter that walks the structured JSON
plan (filters/group_by/operation/top_n) and calls real pandas functions
directly -- there is no `eval()` or `exec()` in this path, so there is
nothing for malicious/broken generated code to exploit.

For teaching purposes, this file ALSO includes `safe_eval_expression()`,
an AST-whitelist based evaluator, for the (optional / advanced) case where
you want to let the LLM emit a single pandas expression string instead of
a plan. It:
  - parses the code with `ast.parse`
  - walks the AST and REJECTS anything that isn't an expression built
    from whitelisted node types (no Import, no function defs, no
    attribute access outside an allowlist, no dunders, no builtins
    except a tiny safe subset)
  - evaluates with `eval(..., {"__builtins__": {}}, restricted_locals)`
    so there is no filesystem, network, or shell access.

IMPORTANT CAVEAT (be explicit, per PART 9):
This is a prototype-grade sandbox, not production-grade. `eval` with
restricted builtins can still be escaped by a sufficiently creative
payload (e.g. via crafted objects). For production, run generated code in
an isolated subprocess/container with no network and a hard CPU/memory/
time limit, and prefer the structured-plan interpreter over free-form
code whenever possible -- that's why it's the primary path here.
"""

from __future__ import annotations
import ast
import operator as op
import pandas as pd

from src.visualization import charts as chart_lib


class ExecutionError(Exception):
    pass


# ---------------------------------------------------------------------
# PRIMARY PATH: interpret the structured plan directly (no eval/exec)
# ---------------------------------------------------------------------

_FILTER_OPS = {
    "equals": lambda s, v: s.astype(str).str.lower() == str(v).lower(),
    "not_equals": lambda s, v: s.astype(str).str.lower() != str(v).lower(),
    "greater_than": lambda s, v: pd.to_numeric(s, errors="coerce") > float(v),
    "less_than": lambda s, v: pd.to_numeric(s, errors="coerce") < float(v),
    "contains": lambda s, v: s.astype(str).str.contains(str(v), case=False, na=False),
    "year_in": lambda s, v: pd.to_datetime(s, errors="coerce").dt.year.isin(v),
}

_AGG_OPS = {
    "mean": "mean", "sum": "sum", "count": "count",
    "min": "min", "max": "max", "median": "median",
}


def _apply_filters(df: pd.DataFrame, filters: list[dict]) -> pd.DataFrame:
    out = df
    for f in filters or []:
        col, opname, val = f["column"], f["operator"], f.get("value")
        if col not in out.columns:
            raise ExecutionError(f"Filter references unknown column '{col}'.")
        if opname not in _FILTER_OPS:
            raise ExecutionError(f"Unsupported filter operator '{opname}'.")
        mask = _FILTER_OPS[opname](out[col], val)
        out = out[mask]
    return out


def _resolve_group_col(df: pd.DataFrame, group_spec: str) -> tuple[pd.DataFrame, str]:
    """Handles 'col' or 'col:month' / 'col:year' group-by specs."""
    if ":" in group_spec:
        col, freq = group_spec.split(":", 1)
        tmp = df.copy()
        tmp[col] = pd.to_datetime(tmp[col], errors="coerce")
        if freq == "month":
            key = tmp[col].dt.to_period("M").astype(str)
        elif freq == "year":
            key = tmp[col].dt.year
        else:
            raise ExecutionError(f"Unsupported group-by frequency '{freq}'.")
        label = f"{col}_{freq}"
        tmp[label] = key
        return tmp, label
    return df, group_spec


def execute_plan(df: pd.DataFrame, plan: dict):
    """
    Returns a dict:
      {"result_type": "scalar"|"table"|"none", "value": ..., "table": df_or_None,
       "figure": plotly_fig_or_None}
    """
    working = _apply_filters(df, plan.get("filters"))
    if working.empty:
        return {"result_type": "none", "value": None, "table": None, "figure": None,
                "note": "No rows match the given filters."}

    intent = plan.get("intent")
    operation = plan.get("operation")
    group_by = plan.get("group_by") or []
    columns = [c for c in (plan.get("columns") or []) if c in df.columns]
    numeric_target = next((c for c in columns if pd.api.types.is_numeric_dtype(df[c])), None)

    # --- percentage ---
    if operation == "percentage_true" and columns:
        col = columns[0]
        series = working[col].astype(str).str.lower()
        positive = series.isin(["yes", "true", "1", "y", "churned"])
        pct = round(100 * positive.mean(), 2) if len(series) else 0.0
        return {"result_type": "scalar", "value": f"{pct}%", "table": None, "figure": None}

    # --- filter / list rows ---
    if operation == "list" or intent == "filter":
        table = working[columns] if columns else working
        return {"result_type": "table", "value": None, "table": table.head(200), "figure": None}

    # --- group-by aggregation ---
    if group_by:
        gdf = working
        group_labels = []
        for g in group_by:
            gdf, label = _resolve_group_col(gdf, g)
            group_labels.append(label)
        if numeric_target is None:
            raise ExecutionError("No numeric column found to aggregate.")
        agg_func = _AGG_OPS.get(operation, "sum")
        grouped = gdf.groupby(group_labels)[numeric_target].agg(agg_func).reset_index()
        grouped = grouped.sort_values(numeric_target, ascending=(plan.get("sort") != "descending"))
        top_n = plan.get("top_n")
        if top_n:
            grouped = grouped.sort_values(numeric_target, ascending=False).head(top_n)

        fig = None
        viz = plan.get("visualization")
        if viz == "line":
            fig = chart_lib.line_chart(grouped[group_labels[0]], grouped[numeric_target],
                                        group_labels[0], numeric_target)
        elif viz in ("bar", "table") or top_n:
            fig = chart_lib.bar_chart(grouped[group_labels[0]].astype(str), grouped[numeric_target],
                                       group_labels[0], numeric_target)
        return {"result_type": "table", "value": None, "table": grouped, "figure": fig}

    # --- plain scalar aggregation ---
    if numeric_target is not None and operation in _AGG_OPS:
        value = getattr(working[numeric_target], _AGG_OPS[operation])()
        return {"result_type": "scalar", "value": round(float(value), 2), "table": None, "figure": None}

    # fallback: just show the filtered table
    return {"result_type": "table", "value": None, "table": working.head(200), "figure": None}


# ---------------------------------------------------------------------
# OPTIONAL / ADVANCED PATH: AST-whitelisted evaluation of a single
# pandas expression string, e.g. df[df["age"] > 60]["claim_amount"].mean()
# ---------------------------------------------------------------------

_ALLOWED_NODES = (
    ast.Expression, ast.Call, ast.Attribute, ast.Subscript, ast.Compare,
    ast.BoolOp, ast.BinOp, ast.UnaryOp, ast.Name, ast.Load, ast.Constant,
    ast.Index, ast.Slice, ast.List, ast.Tuple, ast.Dict,
    ast.And, ast.Or, ast.Not, ast.Eq, ast.NotEq, ast.Gt, ast.Lt, ast.GtE, ast.LtE,
    ast.Add, ast.Sub, ast.Mult, ast.Div, ast.USub,
)

_ALLOWED_ATTRS = {
    "mean", "sum", "count", "min", "max", "median", "std", "var",
    "groupby", "sort_values", "head", "tail", "value_counts", "reset_index",
    "astype", "dt", "str", "year", "month", "isin", "unique", "nunique",
    "round", "abs", "dropna",
}

_BLOCKED_NAMES = {"__import__", "open", "exec", "eval", "os", "sys", "subprocess", "socket"}


def safe_eval_expression(code: str, df: pd.DataFrame):
    """
    Evaluate ONE pandas expression against `df` only. Raises ExecutionError
    for anything outside the whitelist. See module docstring for caveats.
    """
    try:
        tree = ast.parse(code, mode="eval")
    except SyntaxError as e:
        raise ExecutionError(f"Generated code has a syntax error: {e}")

    for node in ast.walk(tree):
        if not isinstance(node, _ALLOWED_NODES):
            raise ExecutionError(f"Disallowed expression element: {type(node).__name__}")
        if isinstance(node, ast.Name) and node.id in _BLOCKED_NAMES:
            raise ExecutionError(f"Use of '{node.id}' is not allowed.")
        if isinstance(node, ast.Name) and node.id not in ("df", "True", "False", "None"):
            raise ExecutionError(f"Unknown identifier '{node.id}' is not allowed (only 'df').")
        if isinstance(node, ast.Attribute) and node.attr.startswith("_"):
            raise ExecutionError("Access to dunder/private attributes is not allowed.")
        if isinstance(node, ast.Attribute) and node.attr not in _ALLOWED_ATTRS and node.attr not in df.columns:
            raise ExecutionError(f"Attribute '.{node.attr}' is not on the allow-list.")

    restricted_globals = {"__builtins__": {}}
    restricted_locals = {"df": df}
    try:
        return eval(compile(tree, "<generated>", "eval"), restricted_globals, restricted_locals)
    except Exception as e:  # noqa: BLE001 - deliberately broad, converted to ExecutionError
        raise ExecutionError(f"Error while executing generated code: {e}")
