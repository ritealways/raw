"""
src/visualization/charts.py

WHAT:
Plotly chart builders. Every function takes a dataframe (or aggregated
result) and returns a plotly Figure. No hard-coded column names anywhere.

WHY:
Both the automatic EDA screen and the chat answers need charts. Keeping
chart code in one place means the LLM's "visualization" field in its plan
(bar / line / hist / box / scatter / heatmap) maps directly to one of
these functions -- the LLM never writes chart code itself, which is safer
and more reliable than asking it to generate matplotlib code.
"""

from __future__ import annotations
import pandas as pd
import plotly.express as px


def histogram(df: pd.DataFrame, column: str):
    return px.histogram(df, x=column, title=f"Distribution of {column}")


def boxplot(df: pd.DataFrame, column: str, by: str | None = None):
    if by:
        return px.box(df, x=by, y=column, title=f"{column} by {by}")
    return px.box(df, y=column, title=f"Boxplot of {column}")


def bar_chart(x_labels, y_values, x_title: str = "", y_title: str = "", title: str = ""):
    return px.bar(x=x_labels, y=y_values, labels={"x": x_title, "y": y_title}, title=title)


def line_chart(x_labels, y_values, x_title: str = "", y_title: str = "", title: str = ""):
    return px.line(x=x_labels, y=y_values, labels={"x": x_title, "y": y_title}, title=title, markers=True)


def scatter_chart(df: pd.DataFrame, x: str, y: str, color: str | None = None):
    return px.scatter(df, x=x, y=y, color=color, title=f"{y} vs {x}")


def correlation_heatmap(corr_df: pd.DataFrame):
    if corr_df.empty:
        return None
    return px.imshow(corr_df, text_auto=True, title="Correlation heatmap", color_continuous_scale="RdBu_r")


def auto_eda_charts(df: pd.DataFrame, schema, max_charts: int = 6):
    """Pick a handful of sensible charts automatically for the EDA tab."""
    from src.utils.schema import column_names_by_role
    roles = column_names_by_role(schema)
    figs = []

    for col in roles["numeric"][:2]:
        figs.append((f"Distribution: {col}", histogram(df, col)))

    for col in roles["categorical"][:2]:
        vc = df[col].value_counts().head(10)
        figs.append((f"Top categories: {col}", bar_chart(vc.index.astype(str), vc.values, col, "count")))

    if roles["date"] and roles["numeric"]:
        d, n = roles["date"][0], roles["numeric"][0]
        ts = df.copy()
        ts[d] = pd.to_datetime(ts[d], errors="coerce")
        ts = ts.dropna(subset=[d]).groupby(pd.Grouper(key=d, freq="MS"))[n].sum().reset_index()
        if len(ts):
            figs.append((f"{n} over time", line_chart(ts[d], ts[n], "date", n)))

    if len(roles["numeric"]) >= 2:
        from src.profiling.eda import correlation_matrix
        corr = correlation_matrix(df)
        heat = correlation_heatmap(corr)
        if heat is not None:
            figs.append(("Correlation heatmap", heat))

    return figs[:max_charts]
