"""
src/profiling/eda.py

WHAT:
A reusable, domain-independent automated EDA engine. Given ANY dataframe,
it computes dataset-level stats, per-column stats, data-quality issues,
outliers, and correlations -- without any hard-coded column names.

WHY:
Two consumers need this:
1. The Streamlit UI (to show the user an EDA report + auto charts).
2. The LLM prompt builder (to give the model real statistics instead of
   letting it guess numbers, which is a major source of hallucination).

HOW:
Pure pandas/numpy. No LLM calls happen in this file at all.
"""

from __future__ import annotations
import pandas as pd
import numpy as np
from src.utils.schema import build_schema, infer_column_role


def dataset_overview(df: pd.DataFrame) -> dict:
    return {
        "n_rows": int(len(df)),
        "n_columns": int(df.shape[1]),
        "memory_usage_mb": round(df.memory_usage(deep=True).sum() / (1024 * 1024), 3),
        "duplicate_rows": int(df.duplicated().sum()),
    }


def missing_value_report(df: pd.DataFrame) -> pd.DataFrame:
    miss = df.isna().sum()
    pct = (miss / len(df) * 100).round(2) if len(df) else miss * 0
    out = pd.DataFrame({"column": miss.index, "missing_count": miss.values, "missing_pct": pct.values})
    return out.sort_values("missing_count", ascending=False).reset_index(drop=True)


def constant_columns(df: pd.DataFrame) -> list[str]:
    return [c for c in df.columns if df[c].nunique(dropna=True) <= 1]


def numeric_summary(df: pd.DataFrame) -> pd.DataFrame:
    num_cols = [c for c in df.columns if infer_column_role(df[c], c) == "numeric"]
    if not num_cols:
        return pd.DataFrame()
    desc = df[num_cols].describe(percentiles=[0.05, 0.25, 0.5, 0.75, 0.95]).T
    desc["outlier_count"] = [count_outliers_iqr(df[c]) for c in num_cols]
    return desc.round(2)


def count_outliers_iqr(series: pd.Series) -> int:
    s = series.dropna()
    if len(s) < 4:
        return 0
    q1, q3 = s.quantile(0.25), s.quantile(0.75)
    iqr = q3 - q1
    if iqr == 0:
        return 0
    lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    return int(((s < lower) | (s > upper)).sum())


def categorical_summary(df: pd.DataFrame, top_n: int = 5) -> dict:
    cat_cols = [c for c in df.columns if infer_column_role(df[c], c) == "categorical"]
    out = {}
    for c in cat_cols:
        vc = df[c].value_counts(dropna=True).head(top_n)
        out[c] = {
            "n_unique": int(df[c].nunique(dropna=True)),
            "top_values": vc.to_dict(),
        }
    return out


def correlation_matrix(df: pd.DataFrame) -> pd.DataFrame:
    num_cols = [c for c in df.columns if infer_column_role(df[c], c) == "numeric"]
    if len(num_cols) < 2:
        return pd.DataFrame()
    return df[num_cols].corr(numeric_only=True).round(2)


def full_eda_report(df: pd.DataFrame) -> dict:
    """One call that returns everything the UI / prompt builder needs."""
    schema = build_schema(df)
    return {
        "schema": schema,
        "overview": dataset_overview(df),
        "missing": missing_value_report(df),
        "constant_columns": constant_columns(df),
        "numeric_summary": numeric_summary(df),
        "categorical_summary": categorical_summary(df),
        "correlation": correlation_matrix(df),
    }


def eda_summary_text(report: dict) -> str:
    """Compact text version of the EDA report, for the LLM prompt (part 6/11)."""
    ov = report["overview"]
    lines = [
        f"Rows: {ov['n_rows']}, Columns: {ov['n_columns']}, "
        f"Duplicate rows: {ov['duplicate_rows']}, Memory: {ov['memory_usage_mb']} MB"
    ]
    miss = report["missing"]
    top_missing = miss[miss["missing_count"] > 0].head(5)
    if len(top_missing):
        lines.append("Columns with missing values: " +
                      ", ".join(f"{r.column}({r.missing_pct}%)" for r in top_missing.itertuples()))
    if report["constant_columns"]:
        lines.append("Constant (useless) columns: " + ", ".join(report["constant_columns"]))
    return "\n".join(lines)
