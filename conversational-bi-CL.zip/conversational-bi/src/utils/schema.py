"""
src/utils/schema.py

WHAT:
Extracts a compact, LLM-friendly "schema" from a pandas DataFrame:
column names, dtypes, a few sample values, and column roles
(numeric / categorical / date / boolean / id-like).

WHY:
We NEVER send the whole dataframe to the LLM (too many tokens, and it
doesn't need raw rows to write pandas code). The LLM only needs to know
what the columns are, what type they are, and a few example values.
This one file is what makes the whole app "domain independent" -- it
works the same way on insurance data, sales data, HR data, etc.
"""

from __future__ import annotations
import pandas as pd
import numpy as np
from dataclasses import dataclass, field


DATE_HINT_TOKENS = ("date", "dt", "day", "time", "_at", "timestamp")
ID_HINT_TOKENS = ("id", "_no", "number", "code")


@dataclass
class ColumnInfo:
    name: str
    dtype: str
    role: str  # "numeric" | "categorical" | "date" | "boolean" | "id" | "text"
    n_unique: int
    n_missing: int
    missing_pct: float
    sample_values: list = field(default_factory=list)


def _looks_like_date(series: pd.Series, name: str) -> bool:
    if pd.api.types.is_datetime64_any_dtype(series):
        return True
    is_stringy = series.dtype == object or pd.api.types.is_string_dtype(series)
    if is_stringy:
        name_l = name.lower()
        if any(tok in name_l for tok in DATE_HINT_TOKENS):
            sample = series.dropna().astype(str).head(20)
            if len(sample) == 0:
                return False
            parsed = pd.to_datetime(sample, errors="coerce", format="mixed")
            return parsed.notna().mean() > 0.8
    return False


def infer_column_role(series: pd.Series, name: str) -> str:
    if pd.api.types.is_bool_dtype(series):
        return "boolean"
    if _looks_like_date(series, name):
        return "date"
    if pd.api.types.is_numeric_dtype(series):
        # numeric columns that are actually IDs (near-unique, name hints at id)
        name_l = name.lower()
        if any(tok in name_l for tok in ID_HINT_TOKENS) and series.nunique() > 0.9 * len(series):
            return "id"
        return "numeric"
    # object / category
    n_unique = series.nunique(dropna=True)
    if n_unique > 0 and n_unique / max(len(series), 1) > 0.9:
        return "id" if n_unique > 50 else "text"
    return "categorical"


def build_schema(df: pd.DataFrame, sample_rows: int = 3) -> list[ColumnInfo]:
    """Build a list of ColumnInfo describing every column in the dataframe."""
    schema: list[ColumnInfo] = []
    n = len(df)
    for col in df.columns:
        series = df[col]
        role = infer_column_role(series, col)
        missing = int(series.isna().sum())
        sample_vals = (
            series.dropna().astype(str).unique()[:sample_rows].tolist()
        )
        schema.append(
            ColumnInfo(
                name=col,
                dtype=str(series.dtype),
                role=role,
                n_unique=int(series.nunique(dropna=True)),
                n_missing=missing,
                missing_pct=round(100 * missing / n, 2) if n else 0.0,
                sample_values=sample_vals,
            )
        )
    return schema


def schema_to_prompt_text(schema: list[ColumnInfo], max_cols: int = 40) -> str:
    """
    Turn the schema into a compact text block for the LLM prompt.
    This is what lets the LLM "understand" a dataset it has never seen,
    without ever receiving the actual rows.
    """
    lines = []
    for c in schema[:max_cols]:
        samples = ", ".join(c.sample_values[:3])
        lines.append(
            f'- "{c.name}" | role={c.role} | dtype={c.dtype} | '
            f"unique={c.n_unique} | missing={c.missing_pct}% | examples=[{samples}]"
        )
    if len(schema) > max_cols:
        lines.append(f"... and {len(schema) - max_cols} more columns (truncated)")
    return "\n".join(lines)


def column_names_by_role(schema: list[ColumnInfo]) -> dict:
    out = {"numeric": [], "categorical": [], "date": [], "boolean": [], "id": [], "text": []}
    for c in schema:
        out.setdefault(c.role, []).append(c.name)
    return out
