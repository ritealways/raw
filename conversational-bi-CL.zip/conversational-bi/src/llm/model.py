"""
src/llm/model.py

WHAT:
Wraps a Hugging Face text-generation model behind one function:
`generate(prompt) -> str`. Two backends are supported:

  1. "hf_local"  -- transformers.pipeline with a local/downloaded model
                    (e.g. meta-llama/Llama-3.2-1B-Instruct, or any small
                    instruct model). Supports 4-bit/8-bit quantization
                    via bitsandbytes when a GPU is available.
  2. "rule_based" -- a small, dependency-free keyword planner used as a
                    FALLBACK so the app still runs end-to-end even if you
                    have not downloaded a model yet / have no GPU. This
                    is what makes the prototype runnable immediately.

WHY:
Beginners often get stuck at "the model won't download / is too slow /
runs out of RAM" before ever seeing the rest of the app work. The
rule_based backend guarantees `streamlit run app.py` works on day one;
once you are ready, flip LLM_BACKEND=hf_local in .env and plug in a real
Llama model.

HOW (sizing guidance -- read this before choosing a model):
- CPU only, 8-16GB RAM  -> use a 1B-3B instruct model
  (e.g. "meta-llama/Llama-3.2-1B-Instruct" or "Qwen/Qwen2.5-1.5B-Instruct").
  Expect several seconds per answer.
- GPU with 6-8GB VRAM   -> 7B-8B model in 4-bit quantization
  (e.g. "meta-llama/Llama-3.1-8B-Instruct" + bitsandbytes load_in_4bit=True).
- GPU with 16GB+ VRAM   -> 7B-8B model in 8-bit or fp16, much faster.
- No local hardware / want reliability -> use a hosted inference
  endpoint (Hugging Face Inference Endpoints, or any OpenAI-compatible
  local server like Ollama/vLLM) and just swap out `generate()`.
Quantization (4-bit/8-bit via bitsandbytes) trades a little accuracy for
a large drop in VRAM/RAM use -- almost always worth it for a prototype.
"""

from __future__ import annotations
import os
import re
import json


class LLMBackend:
    def generate(self, prompt: str, max_new_tokens: int = 400) -> str:
        raise NotImplementedError


class HFLocalBackend(LLMBackend):
    """Loads a real Hugging Face model with transformers.pipeline."""

    def __init__(self, model_name: str, load_in_4bit: bool = False, device_map: str = "auto"):
        from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
        import torch

        quant_kwargs = {}
        if load_in_4bit:
            from transformers import BitsAndBytesConfig
            quant_kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.float16,
            )

        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForCausalLM.from_pretrained(
            model_name,
            device_map=device_map,
            torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
            **quant_kwargs,
        )
        self.pipe = pipeline(
            "text-generation",
            model=self.model,
            tokenizer=self.tokenizer,
        )

    def generate(self, prompt: str, max_new_tokens: int = 400) -> str:
        out = self.pipe(
            prompt,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            temperature=None,
            top_p=None,
            pad_token_id=self.tokenizer.eos_token_id,
        )
        full_text = out[0]["generated_text"]
        return full_text[len(prompt):].strip()


class RuleBasedBackend(LLMBackend):
    """
    Deterministic fallback "planner" that mimics what a well-prompted LLM
    would output, using simple keyword + schema matching. It reads the
    SAME prompt text a real model would receive and extracts the schema
    / question from it, so swapping this out for HFLocalBackend later
    requires zero changes anywhere else in the code.
    """

    AGG_WORDS = {
        "average": "mean", "avg": "mean", "mean": "mean",
        "total": "sum", "sum": "sum",
        "count": "count", "how many": "count",
        "max": "max", "highest": "max", "maximum": "max",
        "min": "min", "lowest": "min", "minimum": "min",
        "median": "median",
    }

    def generate(self, prompt: str, max_new_tokens: int = 400) -> str:
        question_match = re.search(r'Question:\s*"([^"]+)"\s*Plan:\s*$', prompt, re.DOTALL)
        question = question_match.group(1) if question_match else ""
        schema_match = re.search(r"SCHEMA.*?:\n(.*?)\n\n", prompt, re.DOTALL)
        schema_block = schema_match.group(1) if schema_match else ""

        columns = re.findall(r'"([^"]+)"\s*\|\s*role=(\w+)', schema_block)
        col_names = [c[0] for c in columns]
        numeric_cols = [c[0] for c in columns if c[1] == "numeric"]
        cat_cols = [c[0] for c in columns if c[1] in ("categorical", "text")]
        date_cols = [c[0] for c in columns if c[1] == "date"]

        q_lower = question.lower()

        # figure out operation
        operation = "mean"
        for word, op in self.AGG_WORDS.items():
            if word in q_lower:
                operation = op
                break

        # Figure out the target numeric column. We deliberately do NOT fall back
        # to "the first numeric column" when nothing matches -- that would let
        # the app answer confidently about the wrong metric (hallucination-by-
        # proxy). If the question doesn't name a real column, target_col stays
        # None and plan_question() will correctly report "I couldn't find that
        # column" instead of guessing (see PART 14 / test_unknown_question...).
        def _mentions_column(col: str, text: str) -> bool:
            # Word-boundary match so e.g. column "age" doesn't false-match inside "average".
            pattern = r"\b" + re.escape(col.lower().replace("_", " ")) + r"\b"
            if re.search(pattern, text):
                return True
            pattern2 = r"\b" + re.escape(col.lower()) + r"\b"
            return bool(re.search(pattern2, text))

        target_col = next((c for c in numeric_cols if _mentions_column(c, q_lower)), None)
        if target_col is None and len(numeric_cols) == 1 and any(
            w in q_lower for w in ("average", "avg", "mean", "total", "sum", "median", "max", "min")
        ):
            # Only one possible numeric column exists at all -- safe to assume it.
            target_col = numeric_cols[0]

        # figure out group_by column
        group_by = []
        m = re.search(r"\bby (\w+)", q_lower)
        if m:
            candidate = m.group(1)
            match_col = next((c for c in col_names if candidate in c.lower()), None)
            if match_col:
                group_by = [match_col]
        if not group_by and "trend" in q_lower or "over time" in q_lower or "monthly" in q_lower:
            if date_cols:
                group_by = [f"{date_cols[0]}:month"]

        # filters: look for "<value>" mentioned that matches a categorical value in schema samples
        filters = []
        examples_block = re.findall(r'"([^"]+)"\s*\|.*?examples=\[([^\]]*)\]', schema_block)
        for col, examples in examples_block:
            for val in [v.strip() for v in examples.split(",") if v.strip()]:
                if val.lower() and val.lower() in q_lower:
                    filters.append({"column": col, "operator": "equals", "value": val})

        top_n = None
        m = re.search(r"top (\d+)", q_lower)
        if m:
            top_n = int(m.group(1))

        intent = "aggregation"
        if top_n:
            intent = "ranking"
        elif group_by and any("month" in g or "year" in g for g in group_by):
            intent = "time_series"
        elif "compare" in q_lower:
            intent = "comparison"
        elif "percent" in q_lower or "%" in q_lower:
            intent = "percentage"
            operation = "percentage_true"
        elif "show" in q_lower and not target_col:
            intent = "filter"
            operation = "list"

        if target_col is None and intent not in ("filter",):
            plan = {
                "intent": "unknown", "columns": [], "operation": "none",
                "group_by": [], "filters": [], "top_n": None, "sort": None,
                "visualization": "none",
                "explanation": "Could not confidently match the question to a numeric column in this dataset.",
            }
            return json.dumps(plan)

        viz = "none"
        if group_by:
            viz = "line" if intent == "time_series" else "bar"
        elif top_n:
            viz = "bar"

        plan = {
            "intent": intent,
            "columns": [c for c in [target_col] + group_by + [f["column"] for f in filters] if c],
            "operation": operation,
            "group_by": group_by,
            "filters": filters,
            "top_n": top_n,
            "sort": "descending" if top_n else None,
            "visualization": viz,
            "explanation": f"Rule-based fallback plan for: {question}",
        }
        return json.dumps(plan)


def get_backend() -> LLMBackend:
    backend_name = os.getenv("LLM_BACKEND", "rule_based").lower()
    if backend_name == "hf_local":
        model_name = os.getenv("HF_MODEL_NAME", "meta-llama/Llama-3.2-1B-Instruct")
        load_in_4bit = os.getenv("LOAD_IN_4BIT", "false").lower() == "true"
        return HFLocalBackend(model_name=model_name, load_in_4bit=load_in_4bit)
    return RuleBasedBackend()
