"""
src/query/planner.py

WHAT:
The "brain" that turns (schema + EDA summary + chat history + question)
into a validated structured plan (see src/prompts/few_shot.py for the
JSON schema). This is PART 7's pipeline, stages "Intent Understanding"
through "Analytical Plan".

WHY:
Keeping prompt-building, LLM-calling, and JSON-parsing/validation in one
place means app.py stays thin, and it's easy to unit test this file
without ever loading a real model (tests/test_basic.py does exactly that).

HOW:
1. build_prompt() from few_shot.py assembles the full text prompt.
2. backend.generate() calls the LLM (or the rule_based fallback).
3. parse_plan() extracts JSON even if the model added stray text.
4. validate_plan() rejects any column name not present in the schema --
   this is the main anti-hallucination guardrail (PART 14).
5. merge_follow_up() combines a follow-up plan with the previous plan.
"""

from __future__ import annotations
import json
import re

from src.prompts.few_shot import build_prompt
from src.utils.schema import schema_to_prompt_text


class PlanValidationError(Exception):
    pass


def parse_plan(raw_text: str) -> dict:
    """Extract the first JSON object from the model's raw output."""
    raw_text = raw_text.strip()
    # strip markdown fences if present
    raw_text = re.sub(r"^```(json)?|```$", "", raw_text, flags=re.MULTILINE).strip()
    match = re.search(r"\{.*\}", raw_text, re.DOTALL)
    if not match:
        raise PlanValidationError("Model did not return a JSON object.")
    try:
        return json.loads(match.group(0))
    except json.JSONDecodeError as e:
        raise PlanValidationError(f"Could not parse JSON from model output: {e}")


def validate_plan(plan: dict, valid_columns: list[str]) -> tuple[bool, list[str]]:
    """
    Returns (is_valid, problems). A plan is invalid if it references a
    column that does not exist in the dataset -- this is what stops the
    app from ever answering with a hallucinated column.
    """
    problems = []
    valid_set = set(valid_columns)

    def check_col(name):
        base = name.split(":")[0]  # strip ":month" / ":year" suffix
        if base and base not in valid_set:
            problems.append(f"Unknown column referenced: '{base}'")

    for c in plan.get("columns", []) or []:
        check_col(c)
    for g in plan.get("group_by", []) or []:
        check_col(g)
    for f in plan.get("filters", []) or []:
        if isinstance(f, dict) and "column" in f:
            check_col(f["column"])

    return (len(problems) == 0), problems


def merge_follow_up(new_plan: dict, previous_plan: dict | None) -> dict:
    """If new_plan is a follow-up, layer its filters/changes on top of previous_plan."""
    if new_plan.get("intent") != "follow_up_filter" or not previous_plan:
        return new_plan
    merged = dict(previous_plan)
    merged["filters"] = (previous_plan.get("filters") or []) + (new_plan.get("filters") or [])
    if new_plan.get("top_n"):
        merged["top_n"] = new_plan["top_n"]
    if new_plan.get("visualization") not in (None, "same_as_previous"):
        merged["visualization"] = new_plan["visualization"]
    merged["explanation"] = new_plan.get("explanation", previous_plan.get("explanation", ""))
    return merged


def plan_question(
    backend,
    question: str,
    schema,
    eda_summary_text: str,
    history: list[dict],
    previous_plan: dict | None = None,
) -> dict:
    """
    Full PART 7 pipeline for one question. Returns a dict:
      {"ok": bool, "plan": {...} or None, "error": str or None}
    """
    schema_text = schema_to_prompt_text(schema)
    history_text = "\n".join(
        f'Q: {h["question"]}\nA: {h.get("answer_summary", "")}' for h in history[-4:]
    )

    prompt = build_prompt(schema_text, eda_summary_text, history_text, question)
    raw = backend.generate(prompt)

    try:
        plan = parse_plan(raw)
    except PlanValidationError as e:
        return {"ok": False, "plan": None, "error": str(e)}

    plan = merge_follow_up(plan, previous_plan)

    valid_columns = [c.name for c in schema]
    is_valid, problems = validate_plan(plan, valid_columns)
    if not is_valid:
        return {
            "ok": False,
            "plan": plan,
            "error": (
                "I couldn't find the columns needed to answer that in the uploaded dataset. "
                + " ".join(problems)
                + f" Available columns: {', '.join(valid_columns)}"
            ),
        }

    if plan.get("intent") == "unknown":
        return {
            "ok": False,
            "plan": plan,
            "error": plan.get("explanation", "I'm not confident I understood that question for this dataset."),
        }

    return {"ok": True, "plan": plan, "error": None}
