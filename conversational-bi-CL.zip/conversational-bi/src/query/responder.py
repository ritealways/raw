"""
src/query/responder.py

WHAT:
Turns an execution result (from safe_exec.execute_plan) plus the plan
itself into a short, plain-language sentence -- the last stage of the
PART 7 pipeline ("Natural Language Answer").

WHY:
Users don't want to read raw JSON or a dataframe with no context; they
want a sentence like "The average claim amount for Diabetes patients is
$15,700." This is template-based (not another LLM call) to keep the
prototype fast, cheap, and deterministic; swapping in a second LLM call
to "narrate" the result is a natural V2 improvement (see README).
"""

from __future__ import annotations


def summarize_result(plan: dict, exec_result: dict) -> str:
    explanation = plan.get("explanation", "")
    rtype = exec_result["result_type"]

    if rtype == "none":
        return exec_result.get("note", "No matching data was found for that question.")

    if rtype == "scalar":
        return f"{explanation} Result: **{exec_result['value']}**"

    if rtype == "table":
        table = exec_result["table"]
        n = len(table) if table is not None else 0
        return f"{explanation} Showing {n} row(s) below."

    return explanation or "Here is the result."
